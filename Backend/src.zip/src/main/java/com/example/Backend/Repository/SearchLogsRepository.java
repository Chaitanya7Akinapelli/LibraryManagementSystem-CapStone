package com.example.Backend.Repository;

import com.example.Backend.Entity.SearchLogs;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SearchLogsRepository extends JpaRepository<SearchLogs, Long> {
}
