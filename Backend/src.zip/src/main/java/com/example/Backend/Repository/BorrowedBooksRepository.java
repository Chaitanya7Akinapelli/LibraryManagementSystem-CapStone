package com.example.Backend.Repository;

import com.example.Backend.Entity.Book;
import com.example.Backend.Entity.BorrowedBooks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface BorrowedBooksRepository extends JpaRepository<BorrowedBooks, Long> {
    List<BorrowedBooks> findByUserEmail(String userEmail);

    List<BorrowedBooks> findByUserEmailAndBookIsbn(String userEmail, String bookIsbn);

    @Query("SELECT b FROM BorrowedBooks b WHERE b.dueDate < :currentDate AND b.status = 'BORROWED'")
    List<BorrowedBooks> findOverdueBooks(LocalDate currentDate);

    List<BorrowedBooks> findBooksByUserEmail(String userEmail);
}
